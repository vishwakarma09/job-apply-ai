// common/constants.js
// Global constants shared across the extension content script files

window.API_DEFAULT_URL = "https://jobapplyai.owera.ca";
